﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntityFrameworkCodeFirstExistingDatabase
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new BloggingEntities())
            {
                //create and save a new blog
                Console.Write("Enter a name for a new Blog: ");
                var name = Console.ReadLine();

                var blog = new Blog() { Name = name };
                db.Blogs.Add(blog);
                db.SaveChanges();

                //display all blogs in the database
                var query = from b in db.Blogs
                            orderby b.Name
                            select b;

                Console.WriteLine("All blogs in the database");

                foreach (var item in query)
                {
                    Console.WriteLine(item.Name);
                }

                //update an existing blog
                var updateBlog = db.Blogs.First();
                updateBlog.Name = "A new name!";
                db.SaveChanges();

                //remove a blog
                var deleteBlog = db.Blogs.Last();
                db.Blogs.Remove(deleteBlog);
                db.SaveChanges();


                Console.WriteLine("Press any key to exit");
                Console.ReadKey();
            }
        }
    }
}
