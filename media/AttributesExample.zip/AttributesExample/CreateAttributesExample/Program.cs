﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CreateAttributesExample
{
    [MyAttribute("test1!")]
    class Program
    {
        [MyAttribute("test2!")]
        static void Main(string[] args)
        {
        }
    }

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple=true)]
    public class MyAttribute : Attribute
    {
        public string Description { get; set; } //must be read/write

        public MyAttribute(string description)
        {
            Description = description;
        }
    }
}
