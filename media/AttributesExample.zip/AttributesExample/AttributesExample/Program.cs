﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace AttributesExample
{
    class Program
    {
        static void Main(string[] args)
        {
            if (Attribute.IsDefined(typeof(Person), typeof(SerializableAttribute)))
            {
                Console.WriteLine("Serializable attribute is defined");
            }


            //read properties of an attribute
            var attributes = typeof(ConditionalClass)
                            .GetMethod("Test")
                            .GetCustomAttributes().OfType<ConditionalAttribute>()
                            .OrderBy(a => a.ConditionString);

            foreach (var attribute in attributes)
            {
                Console.WriteLine(attribute.ConditionString);
            }
            Console.ReadKey();
        }
    }

    [Serializable]
    public class Person
    {
        
    }

    
    public class ConditionalClass
    {
        [Conditional("DEBUG")]
        public void Test()
        {

        }
    }
}
