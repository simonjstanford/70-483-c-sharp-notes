﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleNamedAssembly
{
    public class Test
    {
        public string Speak()
        {
            return "Hello!";
        }
    }
}
