﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrongNamedAssembly
{
    public class Test
    {
        public string Speak()
        {
            return "Hello World!";
        }
    }
}
