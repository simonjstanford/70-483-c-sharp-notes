﻿using StrongNamedAssembly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PublisherPolicyFileExample
{
    class Program
    {
        static void Main(string[] args)
        {
            var test = new Test();
            Console.WriteLine(test.Speak());

            Console.ReadKey();
        }
    }
}
