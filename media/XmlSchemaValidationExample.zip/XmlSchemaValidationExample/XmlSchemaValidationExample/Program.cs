﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Schema;

namespace XmlSchemaValidationExample
{
    class Program
    {
        static void Main(string[] args)
        {
            var validator = new Validator();
            validator.ValidateXml();
        }
    }

    class Validator
    {
        public void ValidateXml()
        {
            string xsdPath = "person.xsd";
            string xmlPath = "person.xml";

            XmlReader reader = XmlReader.Create(xmlPath);
            XmlDocument document = new XmlDocument();
            document.Schemas.Add("", xsdPath);
            document.Load(reader);

            var eventHandler = new ValidationEventHandler(MyValidationEventHandler);
            document.Validate(eventHandler);

            Console.ReadKey();
        }

        //if something is wrong with the file then this method is called
        private void MyValidationEventHandler(object sender, ValidationEventArgs e)
        {
            switch (e.Severity)
            {
                case XmlSeverityType.Error:
                    Console.WriteLine("Error: {0}", e.Message);
                    break;
                case XmlSeverityType.Warning:
                    Console.WriteLine("Warning: {0}", e.Message);
                    break;
                default:
                    break;
            }
        }
    }
}
